import java.util.ArrayList;

public class Quiz {

    private ArrayList<Question> questions = new ArrayList<>();

    public Quiz() {
        String questionText1 = "Who invented Java? ";
        ArrayList<String> options1 = new ArrayList<>();
        options1.add("Guido van Rossum");
        options1.add("James Gosling");
        options1.add("Dennis Ritchie");
        options1.add("Bjarne Stroustrup");
        String correctAnswer1 = "James Gosling";
        Question question1 = new Question(questionText1, options1, correctAnswer1);
        this.questions.add(question1);

        String questionText2 = "Which of the following is not a keyword? ";
        ArrayList<String> options2 = new ArrayList<>();
        options2.add("this");
        options2.add("continue");
        options2.add("class");
        options2.add("it");
        String correctAnswer2 = "it";
        Question question2 = new Question(questionText2, options2, correctAnswer2);
        this.questions.add(question2);

        String questionText3= "Identify the corrected definition of a package? ";
        ArrayList<String> options3 = new ArrayList<>();
        options3.add("A package is a collection of editing tools");
        options3.add("A package is a collection of classes");
        options3.add("A package is a collection of classes and interfaces");
        options3.add("A package is a collection of interfaces");
        String correctAnswer3 = "A package is a collection of classes and interfaces";
        Question question3 = new Question(questionText3, options3, correctAnswer3);
        this.questions.add(question3);

        String questionText4= "When is the object created with new keyword? ";
        ArrayList<String> options4 = new ArrayList<>();
        options4.add("At run time");
        options4.add("At compile time");
        options4.add("Depends on the code");
        options4.add("None");
        String correctAnswer4 = "At run time";
        Question question4 = new Question(questionText4, options4, correctAnswer4);
        this.questions.add(question4);

        String questionText5 = "Identify the modifier which cannot be used for constructor? ";
        ArrayList<String> options5 = new ArrayList<>();
        options5.add("Public");
        options5.add("Protected");
        options5.add("Private");
        options5.add("Static");
        String correctAnswer5 = "Static";
        Question question5 = new Question(questionText5, options5, correctAnswer5);
        this.questions.add(question5);

        String questionText6 = "Which of the following is not a keyword? ";
        ArrayList<String> options6 = new ArrayList<>();
        options6.add("this");
        options6.add("continue");
        options6.add("class");
        options6.add("it");
        String correctAnswer6 = "it";
        Question question6 = new Question(questionText6, options6, correctAnswer6);
        this.questions.add(question6);

        String questionText7= "Exception created by try block is caught in which block? ";
        ArrayList<String> options7 = new ArrayList<>();
        options7.add("catch");
        options7.add("throw");
        options7.add("final");
        options7.add("none");
        String correctAnswer7 = "catch";
        Question question7 = new Question(questionText7, options7, correctAnswer7);
        this.questions.add(question7);

        String questionText8= "Which of the following exception is thrown when divided by zero statement is executed? ";
        ArrayList<String> options8 = new ArrayList<>();
        options8.add("NullPointerException");
        options8.add("NumberFormatException");
        options8.add("ArithmeticException");
        options8.add("None");
        String correctAnswer8 = "ArithmeticException";
        Question question8 = new Question(questionText8, options8, correctAnswer8);
        this.questions.add(question8);

        String questionText9= "Which of the following is a type of polymorphism in Java Programming? ";
        ArrayList<String> options9 = new ArrayList<>();
        options9.add("Multiple polymorphism");
        options9.add(" Compile time polymorphism");
        options9.add("Multilevel polymorphism");
        options9.add("Execution time polymorphism");
        String correctAnswer9 = "Compile time polymorphism";
        Question question9 = new Question(questionText9, options9, correctAnswer9);
        this.questions.add(question9);

        String questionText10= "What does the expression float a = 35 / 0 return?";
        ArrayList<String> options10 = new ArrayList<>();
        options10.add("0");
        options10.add("Not a Number");
        options10.add("infinity");
        options10.add("Run time Exception");
        String correctAnswer10 = "Run time Exception";
        Question question10 = new Question(questionText10, options10, correctAnswer10);
        this.questions.add(question10);

    }

    public ArrayList<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(ArrayList<Question> questions) {
        this.questions = questions;
    }

}
